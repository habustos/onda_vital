# MIT License

Copyright (c) 2019 - present [AppSeed](http://appseed.us/)

<br />

## Licensing Information

<br />

| Item | - |
| ---------------------------------- | --- |
| License Type | MIT  |
| Use for print | **YES** |
| Create single personal website/app | **YES** |
| Create single website/app for client | **YES** |
| Create multiple website/apps for clients | **YES** |
| Create multiple SaaS applications | **YES** |
| End-product paying users | **YES** |
| Product sale | **YES** |
| Remove footer credits | **YES** |
| --- | --- |
| Remove copyright mentions from source code | NO |
| Production deployment assistance | NO |
| Create HTML/CSS template for sale | NO |
| Create Theme/Template for CMS for sale | NO |
| Separate sale of our UI Elements | NO |

<br />

---
For more information regarding licensing, please contact the AppSeed Service < *support@appseed.us* >
