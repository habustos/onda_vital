from datetime import datetime, timedelta, date


"""for i in range(13):
    day = datetime.now()
    day = day - timedelta(i)
    print(day)
    start = day.strftime("%d-%m-%Y 00:00:00")
    end = day.strftime("%d-%m-%Y 23:59:59")"""

org_string = 'VENEZUELA'
country_name_val = org_string.split(',',1)[0]
print(country_name_val)