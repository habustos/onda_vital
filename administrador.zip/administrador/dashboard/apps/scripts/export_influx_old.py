import  os, sys, time, re
from datetime import datetime
sys.path.append("/home/administrador/Paginaweb/Portal/scripts/")
from conexiones_bd import *
import pandas as pd



"""
#Funcion encargada de almacenar el registro de ejecuciones en la tabla LOGS de POstgres
def log_bulkload(ejecucion,comentario,categoria,proceso,tabla):
    conn = cdrs_connect.conn.raw_connection()
    try:
        cur = conn.cursor()
        querie = f'''INSERT INTO dashboard.ctrl_ejecuciones (fecha,ejecucion,comentario,categoria,proceso,tabla) VALUES (now(),'{ejecucion}','{comentario}','{categoria}','{proceso}','{tabla}')'''
        cur.execute(querie)
    except psycopg2.Error as e:
        print(e,'*-**********************------**********************-*')
        cur.close()
        conn.close()
        pass
    else:
        conn.commit()
        cur.close()
        conn.close()


def clean_files(file):
    with open(file) as string:
        string = open(file).read()
        new_string = re.sub('\.0[|]', '|', string)
        new_file = re.sub('[|]NaT[|]', '|', new_string)
        final_file = str(f"{file[:-4]}_2.csv")
        open(final_file, 'w').write(new_file)
        #os.remove(file)
        return(final_file)


#Funcion encargada de cargar los archivos archivos en tabla zonagen.contadores
def copy_postgres(tabla,file):

    try:
        cur = conn.cursor()
        cur.copy_expert(sql, open(archivo, "r"))
    except psycopg2.Error as e:
        #error = log_bulkload('Fallido',str(tabla+'|'+cdr+'|'+e),'LOAD_FILES','GMSC_OCS',tabla)
        cur.close()
        conn.close()
        print(e)
        pass
        return('Fallido')
    else:
        conn.commit()
        #success = log_bulkload('Exitoso',str(tabla)+'|'+cdr,'LOAD_FILES',,tabla)
        cur.close()
        conn.close()
        #os.remove(archivo)
        return('Exitoso')
    """
conn = zg_connect.conn.raw_connection()
client = influx_connect.connect()
print(client)
query_api = client.query_api()
file = '/home/administrador/Paginaweb/static/files/test.csv'
tabla = 'zonagen.contadores'
copy = (f'''psql -d zonagen -c "\copy {tabla} from '{file}' csv delimiter '|' "''')
"""
Query: using Pandas DataFrame
"""
v = ['-1m', '1m']
for i in range(1,16):
    if i <= 9 :
        q = str(f'''from(bucket: "CONTADORES")
  |> range(start: -1m)
  |> filter(fn: (r) => r["_measurement"] == "Potencia activa importada agregada")
  |> filter(fn: (r) => r["_field"] == "Medidor_0{i}")
  |> yield(name:"last")
''')
    else:
        q = str(f'''from(bucket: "CONTADORES")
  |> range(start: -1m)
  |> filter(fn: (r) => r["_measurement"] == "Potencia activa importada agregada")
  |> filter(fn: (r) => r["_field"] == "Medidor_{i}")
  |> yield(name:"last")
''')
    df = query_api.query_data_frame(q)
    if df.empty == False:
        print(df)
        df.to_csv(file, index=None, sep='|', header=False)
        os.system(copy)
conn.close()
"""
Close client
"""