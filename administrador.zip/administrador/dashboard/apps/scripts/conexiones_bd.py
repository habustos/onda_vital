import psycopg2, influxdb_client
from influxdb import InfluxDBClient
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from sqlalchemy import *
from psycopg2 import Error
from conexiones_bd import *
import sys,os
import pandas as pd


class zg_connect():
    user="zonagen"
    password="Zonagen!2023"
    host="localhost"
    port='5432'
    database="zonagen"
    postgres_str = f'postgresql+psycopg2://{user}:{password}@{host}:{port}/{database}'
    conn = create_engine(postgres_str)

    
    def cursor(self):
        cursor = self.conn.cursor()
        return cursor


class influx_connect:
    token = os.environ.get("INFLUXDB_TOKEN")
    org = "ZONAGEN"
    url = "http://172.16.1.60:8086"
    @classmethod
    def connect(cls):
        return InfluxDBClient(url=cls.url, token=cls.token, org=cls.org)
    def close(self):
        self.client.__del__()
