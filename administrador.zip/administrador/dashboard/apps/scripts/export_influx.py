import os, sys, time, re
from datetime import datetime

sys.path.append("/home/administrador/dashboard/apps/scripts/")
from conexiones_bd import *
import pandas as pd

def clean_files(file):
    with open(file) as string:
        string = open(file).read()
        new_string = re.sub('\.0[|]', '|', string)
        new_file = re.sub('[|]NaT[|]', '|', new_string)
        final_file = str(f"{file[:-4]}_2.csv")
        open(final_file, 'w').write(new_file)
        copy = (f'''psql -d zonagen -c "\copy zonagen.contadores from '{final_file}' csv delimiter '|' "''')
        os.system(copy)

        return(final_file)


conn = zg_connect.conn.raw_connection()
client = influx_connect.connect()
query_api = client.query_api()
file = '/home/administrador/dashboard/apps/scripts/files/influx_to_postgres.csv'
tabla = 'zonagen.contadores'

"""
Query: using Pandas DataFrame
"""
medicion = ['Energía activa importada agregada','Energía reactiva importada agregada','Energía aparente importada agregada',
                      'Energia activa importada fase 1','Energia activa importada fase 2','Energia activa importada fase 3',
                      'Energia reactiva importada fase 1','Energia reactiva importada fase 2','Energia reactiva importada fase 3',
                      'Enrgia aparente importada fase 1','Enrgia aparente importada fase 2','Enrgia aparente importada fase 3',
                      'Potencia activa importada agregada','Potencia reactiva importada agregada','Potencia aparente importada agregada']
for m in range(1, 16):
    for p in medicion:
        if m <= 9:
            q = str(f'''from(bucket: "CONTADORES")
            |> range(start: -1m)
            |> filter(fn: (r) => r["_measurement"] == "{p}")
            |> filter(fn: (r) => r["_field"] == "Medidor_0{m}")
            |> yield(name:"last")''')
        else:
            q = str(f'''from(bucket: "CONTADORES")
            |> range(start: -1m)
            |> filter(fn: (r) => r["_measurement"] == "{p}")
            |> filter(fn: (r) => r["_field"] == "Medidor_{m}")
            |> yield(name:"last")''')
        df = query_api.query_data_frame(q)
        df = df[["_stop","_value","_field","_measurement"]]
        #print(df['measurement'])
        print(df)
        df.to_csv(file, index=None, sep='|', header=False)
        clean_files(file)
conn.close()
"""
Close client
"""

"""
#Funcion encargada de almacenar el registro de ejecuciones en la tabla LOGS de POstgres
def log_bulkload(ejecucion,comentario,categoria,proceso,tabla):
    conn = cdrs_connect.conn.raw_connection()
    try:
        cur = conn.cursor()
        querie = f'''INSERT INTO dashboard.ctrl_ejecuciones (fecha,ejecucion,comentario,categoria,proceso,tabla) VALUES (now(),'{ejecucion}','{comentario}','{categoria}','{proceso}','{tabla}')'''
        cur.execute(querie)
    except psycopg2.Error as e:
        print(e,'*-**********************------**********************-*')
        cur.close()
        conn.close()
        pass
    else:
        conn.commit()
        cur.close()
        conn.close()




#Funcion encargada de cargar los archivos archivos en tabla zonagen.contadores
def copy_postgres(tabla,file):

    try:
        cur = conn.cursor()
        cur.copy_expert(sql, open(archivo, "r"))
    except psycopg2.Error as e:
        #error = log_bulkload('Fallido',str(tabla+'|'+cdr+'|'+e),'LOAD_FILES','GMSC_OCS',tabla)
        cur.close()
        conn.close()
        print(e)
        pass
        return('Fallido')
    else:
        conn.commit()
        #success = log_bulkload('Exitoso',str(tabla)+'|'+cdr,'LOAD_FILES',,tabla)
        cur.close()
        conn.close()
        #os.remove(archivo)
        return('Exitoso')
    """
