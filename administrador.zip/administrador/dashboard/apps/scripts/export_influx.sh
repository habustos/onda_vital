. /home/administrador/.profile
#!/usr/bin/ksh
#########################################################
export INFLUXDB_TOKEN=n8r0z_BmM2n-6nhCnTr-7hkGdl1IGCG5nLj6qQUKDfFdwxMnWhfus27KN0visbs4pWvtJmhisb59uhLE_6Mvqg==


python3 /home/administrador/dashboard/apps/scripts/export_influx.py 
