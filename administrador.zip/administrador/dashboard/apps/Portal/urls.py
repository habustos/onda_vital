from django.urls import path
from django.contrib import admin
from . import views
from Portal.views import login
from Portal.views import index



urlpatterns = [
    path('admin/', admin.site.urls),
    path('index/', views.index),
    #path('login/', login),
    path('profile/', views.profile),
    #path('register/', views.register),
    path('table/', views.table),
]
