from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request, "Portal/index.html")

def login(request):
    return render(request, "Portal/login.html")

def profile(request):
    return render(request, "Portal/profile.html")

def register(request):
    return render(request, "Portal/register.html")

def table(request):
    return render(request, "Portal/table.html")

