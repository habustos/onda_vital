# -*- encoding: utf-8 -*-

import os, json
from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from django.template import loader
from django.urls import reverse
from django.db.models import Sum, Count
from django.db import connection
from .models import *
import pandas as pd
from django.utils import timezone



def df_to_html(df):
    json_records = df.reset_index().to_json(orient='records')
    df = []
    records = json.loads(json_records)
    return records


def df_matriz(q):
    file = '/home/administrador/dashboard/apps/scripts/files/matriz.csv'
    connection.timezone = timezone.get_current_timezone()
    df = pd.read_sql_query(q,con=connection)
    df['fecha'] = pd.to_datetime(df['fecha'])
    #df['valor'] = df['valor'].astype(int)
    df.set_index('fecha', inplace=True)
    df_pivot = df.pivot_table(index=df.index.date, columns=df.index.hour, values='valor', aggfunc='sum', fill_value=0)
    df['total'] = df_pivot.sum(axis=1)
    df = df_pivot.reset_index()
    df['index'] = df['index'].astype(str)
    df = df_to_html(df)
    return df


@login_required(login_url="/login/")
def index(request):
    username = request.user
    dia = request.POST.get('seleccionar_dia')
    grupo = request.user.groups.all()[0].name
    mediciones_1 =['Energía activa importada agregada','Energía reactiva importada agregada','Energía aparente importada agregada']
    mediciones = '\', \''.join(map(str, mediciones_1))
    clientes = contadores.objects.raw(f'''select id, username as cliente from auth_user where is_superuser <> 'true' ''')
    cliente = request.POST.get('seleccion_cliente')
    if dia is not None and cliente is not None:
        # Ambas variables contienen información, entonces se admite el formulario del grupo administrador
        if request.method == 'POST' and 'buscar_dia':
            q_user = (f'''psql -d zonagen -c "SET TIME ZONE 'America/Bogota';
            drop table if exists zonagen.zonagen.home_contadores;
            create table zonagen.zonagen.home_contadores as (select ROW_NUMBER() OVER (ORDER BY fecha::timestamptz asc) id, fecha, valor, '{cliente}' contador, medicion
            from (select distinct(medicion), left(fecha::varchar,13)||':00' fecha,round((sum(valor)/1000),1) valor from zonagen.contadores
            where (contador = '{cliente}' and fecha::date = '{dia}')
            group by medicion,left(fecha::varchar,13)||':00') a);"''')
            os.system(q_user)
            matriz_m_e_a_q = f'''select fecha::timestamp,valor, medicion from zonagen.contadores where medicion = 'Energía activa importada agregada' and (contador = '{cliente}' and EXTRACT(MONTH FROM fecha) = EXTRACT(MONTH FROM '{dia}'::timestamp) )'''
            matriz_m_e_r_q = f'''select fecha::timestamp,valor, medicion from zonagen.contadores where medicion = 'Energía reactiva importada agregada' and (contador = '{cliente}' and EXTRACT(MONTH FROM fecha) = EXTRACT(MONTH FROM '{dia}'::timestamp) )'''
            matriz_m_e_r_p_q = f'''with t_energia_activa as (
        select fecha,valor energia_activa
        from zonagen.contadores
        where (EXTRACT(MONTH FROM fecha::date) = EXTRACT(MONTH FROM current_date) and medicion='Energía activa importada agregada' and contador = '{cliente}')
        ),
     t_energia_reactiva as (
        select fecha,valor energia_reactiva
        from zonagen.contadores where (EXTRACT(MONTH FROM fecha::date) = EXTRACT(MONTH FROM '{date}'::timestamp) and medicion='Energía reactiva importada agregada' and contador = '{cliente}')),
     energia_reactiva_f as (
        select TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00') fecha,energia_reactiva,energia_activa,
        CASE
        WHEN energia_reactiva > (energia_activa/2) then
        energia_reactiva - (energia_activa/2)
        else 0
            END AS excesos
        from t_energia_activa ea inner join t_energia_reactiva er
        on TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00')=TO_CHAR(er.fecha, 'YYYY-MM-DD HH24:00')
        group by TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00'),ea.energia_activa,er.energia_reactiva
        )
        select
        fecha,round((sum(excesos/1000)/10000),1) valor
        from energia_reactiva_f
        group by fecha'''
            matriz_e_a = df_matriz(matriz_m_e_a_q)
            matriz_e_r = df_matriz(matriz_m_e_r_q)
            print(matriz_m_e_r_p_q)
            matriz_e_r_p = df_matriz(matriz_m_e_r_p_q)
        excesos = contadores.objects.raw(f'''with t_energia_activa as (
            select fecha,round((sum(valor)/1000),1) energia_activa
            from zonagen.home_contadores where medicion='Energía activa importada agregada'
            group by fecha),
            t_energia_reactiva as (
            select fecha,round((sum(valor)/1000),1) energia_reactiva
            from zonagen.home_contadores where medicion='Energía reactiva importada agregada'
            group by fecha)
            select ROW_NUMBER() OVER (ORDER BY ea.fecha asc) id,ea.fecha,ea.energia_activa,er.energia_reactiva,
            CASE
            WHEN sum(er.energia_reactiva) > sum(ea.energia_activa/2) then
            round(sum(er.energia_reactiva) - sum(ea.energia_activa/2)/1000)
            else 0
                END AS excesos
            from t_energia_activa pa inner join t_energia_reactiva pr
            on ea.fecha=er.fecha
            group by ea.fecha,er.energia_reactiva,ea.energia_activa''')
        energia_activa_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
        round((sum(valor)/1000),1) valor, fecha
        from zonagen.home_contadores
        where medicion = 'Energía activa importada agregada'
        group by fecha''')
        energia_reactiva_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
        round((sum(valor)/1000),1) valor, fecha
        from zonagen.home_contadores
        where medicion = 'Energía reactiva importada agregada'
        group by fecha''')
        energia_aparente_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
        round((sum(valor)/1000),1) valor, fecha
        from zonagen.home_contadores
        where medicion = 'Energía aparente importada agregada'
        group by fecha''')
        nombre_cliente  = User.objects.get(username=cliente)
        html_template = loader.get_template('home/index.html')
        context = {
                       'energia_activa_importada_agregada':energia_activa_importada_agregada,
                       'energia_reactiva_importada_agregada':energia_reactiva_importada_agregada,
                       'energia_aparente_importada_agregada':energia_aparente_importada_agregada,
                       'nombre_cliente':nombre_cliente,
                       'grupo':grupo,
                       'excesos': excesos,
                       'matriz_e_a':matriz_e_a,
                       'matriz_e_r': matriz_e_r,
                       'matriz_e_r_p':matriz_e_r_p,
                       'clientes':clientes}
        return HttpResponse(html_template.render(context, request))
        #####################
        ##VISTA CLIENTE######
        #####################
    else:
        if request.method == 'POST' and 'buscar_dia':
            q_user = (f'''psql -d zonagen -c "drop table if exists zonagen.zonagen.home_contadores;
            create table zonagen.zonagen.home_contadores as (select ROW_NUMBER() OVER (ORDER BY fecha asc) id, fecha, round((sum(valor)/1000),1) valor, '{username}' contador, medicion
         from (select distinct(medicion), TO_CHAR(fecha, 'YYYY-MM-DD HH24:00')::timestamp AS fecha,valor, contador from zonagen.contadores
         where (contador = '{username}' and fecha::date = '{dia}')) a
         group by medicion,fecha order by 2 DESC);
         SELECT * FROM Zonagen.home_contadores limit 10"''')
            os.system(q_user)
        matriz_m_e_a_q = f'''select fecha,valor, medicion from zonagen.contadores where medicion = 'Energía activa importada agregada' and (contador = '{username}' and EXTRACT(MONTH FROM fecha) = EXTRACT(MONTH FROM current_date))'''
        matriz_m_e_r_q = f'''select fecha,valor, medicion from zonagen.contadores where medicion = 'Energía reactiva importada agregada' and (contador = '{username}' and EXTRACT(MONTH FROM fecha) = EXTRACT(MONTH FROM current_date))'''
        matriz_m_e_r_p_q = f'''with t_energia_activa as (
        select fecha,valor energia_activa
        from zonagen.contadores
        where (EXTRACT(MONTH FROM fecha::date) = EXTRACT(MONTH FROM current_date) and medicion='Energía activa importada agregada' and contador = '{username}')
        ),
     t_energia_reactiva as (
        select fecha,valor energia_reactiva
        from zonagen.contadores where (EXTRACT(MONTH FROM fecha::date) = EXTRACT(MONTH FROM current_date) and medicion='Energía reactiva importada agregada' and contador = '{username}')),
     energia_reactiva_f as (
        select TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00') fecha,energia_reactiva,energia_activa,
        CASE
        WHEN energia_reactiva > (energia_activa/2) then
        energia_reactiva - (energia_activa/2)
        else 0
            END AS excesos
        from t_energia_activa ea inner join t_energia_reactiva er
        on TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00')=TO_CHAR(er.fecha, 'YYYY-MM-DD HH24:00')
        group by TO_CHAR(ea.fecha, 'YYYY-MM-DD HH24:00'),ea.energia_activa,er.energia_reactiva
        )
        select
        fecha,round((sum(excesos/1000)/10000),1) valor
        from energia_reactiva_f
        group by fecha '''
        matriz_e_a = df_matriz(matriz_m_e_a_q)
        matriz_e_r = df_matriz(matriz_m_e_r_q)
        #print(matriz_m_e_a_q,'##################################################################')
        matriz_e_r_p = df_matriz(matriz_m_e_r_p_q)
        excesos = contadores.objects.raw(f'''with t_energia_activa as (
            select TO_CHAR(fecha, 'YYYY-MM-DD HH24:00') fecha,round((sum(valor)/1000),1) energia_activa
            from zonagen.home_contadores where medicion='Energía activa importada agregada'
            group by TO_CHAR(fecha, 'YYYY-MM-DD HH24:00')),
            t_energia_reactiva as (
            select TO_CHAR(fecha, 'YYYY-MM-DD HH24:00') fecha,round((sum(valor)/1000),1) energia_reactiva
            from zonagen.home_contadores where medicion='Energía reactiva importada agregada'
            group by TO_CHAR(fecha, 'YYYY-MM-DD HH24:00'))
            select ROW_NUMBER() OVER (ORDER BY ea.fecha asc) id,ea.fecha,ea.energia_activa,er.energia_reactiva,
            CASE
            WHEN sum(er.energia_reactiva) > sum(ea.energia_activa/2) then
            round(sum(er.energia_reactiva) - sum(ea.energia_activa/2)/1000)
            else 0
                END AS excesos
            from t_energia_activa ea inner join t_energia_reactiva er
            on ea.fecha = er.fecha
            group by ea.fecha,er.energia_reactiva,ea.energia_activa''')
        print(f'''with t_energia_activa as (
            select TO_CHAR(fecha, 'YYYY-MM-DD HH24:00') fecha,round((sum(valor)/1000),1) energia_activa
            from zonagen.home_contadores where medicion='Energía activa importada agregada'
            group by TO_CHAR(fecha, 'YYYY-MM-DD HH24:00')),
            t_energia_reactiva as (
            select TO_CHAR(fecha, 'YYYY-MM-DD HH24:00') fecha,round((sum(valor)/1000),1) energia_reactiva
            from zonagen.home_contadores where medicion='Energía reactiva importada agregada'
            group by TO_CHAR(fecha, 'YYYY-MM-DD HH24:00'))
            select ROW_NUMBER() OVER (ORDER BY ea.fecha asc) id,ea.fecha,ea.energia_activa,er.energia_reactiva,
            CASE
            WHEN sum(er.energia_reactiva) > sum(ea.energia_activa/2) then
            round(sum(er.energia_reactiva) - sum(ea.energia_activa/2)/1000)
            else 0
                END AS excesos
            from t_energia_activa ea inner join t_energia_reactiva er
            on ea.fecha = er.fecha
            group by ea.fecha,er.energia_reactiva,ea.energia_activa''','######################################################')
        energia_activa_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
            sum(valor)/1000 valor, fecha
            from zonagen.home_contadores
            where medicion = 'Energía activa importada agregada'
            group by fecha''')
        energia_reactiva_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
            round((sum(valor)/1000),1) valor, fecha
            from zonagen.home_contadores
            where medicion = 'Energía reactiva importada agregada'
            group by fecha''')
        energia_aparente_importada_agregada = contadores.objects.raw(f'''select ROW_NUMBER() OVER (ORDER BY fecha asc) id,
            round((sum(valor)/1000),1) valor, fecha
            from zonagen.home_contadores
            where medicion = 'Energía aparente importada agregada'
            group by fecha''')
        html_template = loader.get_template('home/index.html')
        context = {'energia_activa_importada_agregada': energia_activa_importada_agregada,
                   'energia_reactiva_importada_agregada': energia_reactiva_importada_agregada,
                   'energia_aparente_importada_agregada': energia_aparente_importada_agregada,
                   'matriz_e_a':matriz_e_a,
                   'matriz_e_r': matriz_e_r,
                   'matriz_e_r_p':matriz_e_r_p,
                   'excesos': excesos,
                   'grupo': grupo,
                   'clientes': clientes}
    return HttpResponse(html_template.render(context, request))


"""
vista con limitacion de vista de errores en prodiccion,
esto evita que se muestren logs desde los dispositivos y
enviando en su defecto una plantilla de error
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))
"""
